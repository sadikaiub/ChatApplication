import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-area',
  templateUrl: './video-area.component.html',
  styleUrls: ['./video-area.component.css']
})
export class VideoAreaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
