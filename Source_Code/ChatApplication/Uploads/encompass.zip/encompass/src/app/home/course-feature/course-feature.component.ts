import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-feature',
  templateUrl: './course-feature.component.html',
  styleUrls: ['./course-feature.component.css']
})
export class CourseFeatureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
