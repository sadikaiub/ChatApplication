import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-course',
  templateUrl: './popular-course.component.html',
  styleUrls: ['./popular-course.component.css']
})
export class PopularCourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
