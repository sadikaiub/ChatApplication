import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import {CmspageModule} from './cmspage/cmspage.module';

import { AdminModule } from './admin/admin.module';
import { AuthModule } from './auth/auth.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MenuComponent } from './menu/menu.component';
import { HomeBannerComponent } from './home-banner/home-banner.component';
import { CourseFeatureComponent } from './home/course-feature/course-feature.component';
import { PopularCourseComponent } from './home/popular-course/popular-course.component';
import { VideoAreaComponent } from './home/video-area/video-area.component';
import { OtherFeatureComponent } from './home/other-feature/other-feature.component';
import { TestimonialsComponent } from './home/testimonials/testimonials.component';
import { RegistrationComponent } from './home/registration/registration.component';
import { BlogPostComponent } from './home/blog-post/blog-post.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuComponent,
    HomeBannerComponent,
    CourseFeatureComponent,
    PopularCourseComponent,
    VideoAreaComponent,
    OtherFeatureComponent,
    TestimonialsComponent,
    RegistrationComponent,
    BlogPostComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CmspageModule,
    AdminModule,
    AuthModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
 